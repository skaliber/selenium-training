Selenium.version = "@VERSION@";
Selenium.revision = "@REVISION@";

window.top.document.title += " v" + Selenium.version + " [" + Selenium.revision + "]";

